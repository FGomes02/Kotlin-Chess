fun buildMenu(): String {
    return ("1-> Start New Game;\n0-> Exit Game;\n")
}

fun checkName(name: String): Boolean {
    val maiuscula = 'A'..'Z'
    val minuscula = 'a'..'z'
    var spaces = 0
    var capsCheck = true
    var count = 0

    while (count < name.length) {
        val char = name[count]
        if (spaces > 1){ return false}
        else if (char == ' ') { spaces++; capsCheck = true }
        else if (capsCheck) {if (char !in maiuscula) return false else capsCheck = false}
        else if (char !in minuscula) return false
        count += 1
    }
    if (spaces != 1 || name[name.length - 1] == ' '){ return false}

    return true
}

fun showChessLegendOrPieces(message: String): Boolean? {
    if (message == "y" || message == "Y") {
        return true
    } else if (message == "n" || message == "N") {
        return false
    } else {
        return null
    }
}

fun checkIsNumber(number: String): Boolean {
    return number.toIntOrNull() != null
}

fun getCoordinates (readText: String?): Pair<Int, Int>?{

}

fun checkRightPieceSelected(pieceColor: String, turn: Int): Boolean{

}

fun isCoordinateInsideChess (coord: Pair<Int, Int>,numColumns: Int,numLines: Int):Boolean{

}

fun isValidTargetPiece(currentSelectedPiece: Pair<String, String>,currentCoord : Pair<Int, Int>,
                       targetCoord : Pair<Int, Int>, pieces : Array<Pair<String, String>?>,
                       numColumns: Int, numLines: Int): Boolean{

}

fun movePiece( pieces :
               Array<Pair<String, String>?>,
               numColumns: Int, numLines: Int,
               currentCoord: Pair<Int, Int>,
               targetCoord: Pair<Int, Int>,
               totalPiecesAndTurn : Array<Int>):
        Boolean{

}

fun startNewGame (whitePlayer: String,
                  blackPlayer: String,
                  pieces : Array<Pair<String, String>?>,
                  totalPiecesAndTurn : Array<Int?>,numColumns: Int,numLines: Int,
                  showLegend: Boolean= false,
                  showPieces: Boolean = false){

}

fun isHorseValid(currentCoord:
                 Pair<Int, Int>,targetCoord : Pair<Int,
        Int>,pieces : Array<Pair<String,
        String>?>,numColumns: Int, numLines:
                 Int): Boolean{

}

fun isKingValid(currentCoord: Pair<Int,
        Int>,targetCoord : Pair<Int,
        Int>,pieces: Array<Pair<String,
        String>?>,numColumns: Int,numLines:
                Int):Boolean{

}

fun isTowerValid(currentCoord:
                 Pair<Int, Int>,targetCoord: Pair<Int,
        Int>,pieces: Array<Pair<String,
        String>?>,numColumns: Int,numLines:
                 Int):Boolean{

}

fun isBishopValid(currentCoord:
                  Pair<Int, Int>,targetCoord: Pair<Int,
        Int>,pieces: Array<Pair<String,
        String>?>,numColumns: Int,numLines:
                  Int): Boolean{

}

fun isQueenValid(currentCoord:
                 Pair<Int, Int>,targetCoord: Pair<Int,
        Int>,pieces: Array<Pair<String,
        String>?>,numColumns: Int,numLines:
                 Int):Boolean{

}

fun isKnightValid(currentCoord:
                  Pair<Int, Int>,targetCoord: Pair<Int,
        Int>,pieces: Array<Pair<String,
        String>?>,numColumns: Int,numLines:
                  Int):Boolean{

}

fun createInitialBoard(numColumns: Int,numLines: Int): Array<Pair<String,String>?> {
    val collumnLetter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    var array = arrayOfNulls<Pair<String,String>>(numColumns*numLines)
    var lineNum = 1; var colNum = 0; var count = 0

    while(count < array.size ){
        while(colNum < numColumns){
            array[count] = null
            colNum++
            count++
        }
        lineNum++
        colNum = 0
    }

    return array
}

fun convertStringToUnicode(piece: String, color: String): String{
    var unicode = " "
    if(color == "w"){
        when(piece){
            "H" -> unicode = "\u2658"
            "T" -> unicode = "\u2656"
            "P" -> unicode = "\u2659"
            "K" -> unicode = "\u2654"
            "B" -> unicode = "\u2657"
            "Q" -> unicode = "\u2655"
            else -> unicode = " "
        }
    }else if(color == "b"){
        when(piece){
            "H" -> unicode = "\u265E"
            "T" -> unicode = "\u265C"
            "P" -> unicode = "\u265F"
            "K" -> unicode = "\u265A"
            "B" -> unicode = "\u265D"
            "Q" -> unicode = "\u265B"
            else -> unicode = " "
        }
    }else{
        unicode = " "
    }

    return unicode
}

fun drawSquares(numColumns: Int, line: Int, numLines: Int, drawLegend: Boolean = false, drawPieces: Boolean = false,pieces: Array<Pair<String,String>?>): String{
    var board = ""
    val esc: String = Character.toString(27)
    val end = "$esc[0m"
    val startBlue = "$esc[30;44m" ; val startGrey = "$esc[30;47m"; val startWhite = "$esc[30;30m"
    var piece = ""
    var columnCount = 0; var arrayCount = 0
    var lineCount = line


    while(lineCount < numLines){
        columnCount = 0
        if(drawLegend){board += "$startBlue ${lineCount + 1} $end"}

        if(lineCount%2 == 0){
            while (columnCount < numColumns){
                piece = convertStringToUnicode("${pieces[arrayCount]?.first}","${pieces[arrayCount]?.second}")
                if(drawPieces == false){piece = " "}
                if(columnCount % 2==0){
                    board += "$startGrey $piece $end"
                }else{
                    board += "$startWhite $piece $end"
                }
                columnCount++
                arrayCount++
            }
        }else{
            while (columnCount < numColumns){
                piece = convertStringToUnicode("${pieces[arrayCount]?.first}","${pieces[arrayCount]?.second}")
                if(drawPieces == false){piece = " "}
                if(columnCount % 2==0){
                    board += "$startWhite $piece $end"
                }else{
                    board += "$startGrey $piece $end"
                }
                columnCount++
                arrayCount++
            }
        }

        if(drawLegend){board += "$startBlue   $end"}
        board += "\n"
        lineCount += 1

    }

    return board
}

fun buildBoard(numColumns: Int,numLines: Int, showLegend: Boolean = false, showPieces: Boolean = false,pieces: Array<Pair<String,String>?>): String{
    val esc: String = Character.toString(27)
    val end = "$esc[0m"
    val startBlue = "$esc[30;44m"
    var board = ""
    val drawBlue = "$startBlue   $end"
    val collumnLetter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    var columnLegend = 0

    if (showLegend) {
        board += drawBlue
        while (columnLegend < numColumns) {
            board += "$startBlue ${collumnLetter.get(columnLegend)} $end"
            columnLegend++
        }
        board += drawBlue + "\n"

        board += drawSquares(numColumns, 0, numLines,showLegend, showPieces, pieces)

        board += drawBlue
        columnLegend = 0
        while (columnLegend < numColumns) {
            board += drawBlue
            columnLegend++
        }
        board += drawBlue + "\n"
    } else {
        board += drawSquares(numColumns, 0, numLines, showLegend, showPieces,pieces)
    }

    return board

}

fun createTotalPiecesAndTurn(numColumns: Int, numLines: Int): Array<Int?>{
    return arrayOf((numColumns*numLines)/(numColumns/2),(numColumns*numLines)/(numColumns/2),0)
}

fun main() {
    var columns = 0; var lines = 0; var showPieces: Boolean = false; var showLegend: Boolean = false; val invalid = "Invalid response."
    println("Welcome to the Chess Board Game!")
    do {
        println(buildMenu()); val escolha: Int? = readLine()?.toIntOrNull()

        if (escolha == null || escolha != 1) return

        do {
            println("First player name?\n")
            val firstName = readLine();var checkName1 = false
            if (firstName != null) {checkName1 = checkName(firstName)}
            if (checkName1 == false) println(invalid)

        } while (checkName1 == false)

        do {
            var checkName2 = false
            println("Second player name?\n")
            val secondName = readLine()
            if (secondName != null) {checkName2 = checkName(secondName)}
            if (checkName2 == false) println(invalid)

        } while (checkName2 == false)

        do {
            var checkColumn = false
            println("How many chess columns?\n")
            val numColumns = readLine()
            if (numColumns != null) {
                checkColumn = checkIsNumber(numColumns)
                if(checkColumn) {
                    columns = numColumns.toInt()
                    if (columns < 5) checkColumn = false
                }
            }
            if (checkColumn == false) println(invalid)

        } while (checkColumn == false)

        do {
            var checkLineNum = false
            println("How many chess lines?\n")
            val numLines = readLine()
            if (numLines != null) {
                checkLineNum = checkIsNumber(numLines)
                if(checkLineNum) {
                    lines = numLines.toInt()
                    if (lines < 5) checkLineNum = false
                }
            }
            if (checkLineNum == false) println(invalid)

        } while (checkLineNum == false)

        do {
            var checkLegend : Boolean? = false
            println("Show legend (y/n)?\n")
            val legendResponse = readLine()
            if (legendResponse != null) {
                checkLegend = showChessLegendOrPieces(legendResponse)
                if (checkLegend != null) showLegend = checkLegend
            }
            if (checkLegend == null) println(invalid)

        } while (checkLegend == null || false)

        do {
            var checkPiece : Boolean? = false
            println("Show pieces (y/n)?\n")
            val pieceResponse = readLine()
            if (pieceResponse != null) {
                checkPiece = showChessLegendOrPieces(pieceResponse)
                if (checkPiece != null) showPieces = checkPiece
            }
            if (checkPiece == null) println(invalid)

        } while (checkPiece == null || false)
        var totalTurnsArray = createTotalPiecesAndTurn(columns,lines)
        var boardArray = createInitialBoard(columns,lines)
        println(buildBoard(columns,lines,showLegend,showPieces,boardArray))
    } while (escolha == 1)


}